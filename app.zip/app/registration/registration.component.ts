import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { Register } from './Register';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  RegisterObj: Register = new Register();
  errMsg1: string="";
  errMsg2: string="";
  regexEmail = new RegExp(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/);
  regexPan = new RegExp(/^([A-Za-z]){5}([0-9]){4}([A-Za-z]){1}?$/);
  regexMobile = new RegExp(/^[1-9]([0-9]){9}?$/);
  errEmail: string="";
  errPan: string="";
  errMsgDt: string = "";
  msg: any = "";
  validMsg: string = "";

  registerArray: Register[] = [];
  constructor(private regServ: RegistrationService, private router:Router) { }

  ngOnInit(): void {
  }

  MinMobile()
  {
    if(this.RegisterObj.mobileNumber.toString().length!=10 || !(this.regexMobile.test(this.RegisterObj.mobileNumber.toString())))
    this.errMsg1="Please enter 10 digit Mobile Number";
    else
    this.errMsg1="";
  }

  MinAadhar()
  {
    if(this.RegisterObj.applicantAadhar.toString().length!=12 || this.RegisterObj.applicantAadhar ==0)
    this.errMsg2="Please enter valid Aadhar Number";
    else
    this.errMsg2="";
  }

  validateEmail(){
    if(this.regexEmail.test(this.RegisterObj.emailId))
      this.errEmail="";
    else
      this.errEmail="Please enter valid email address";

  }

  validatePan(){
    if(this.regexPan.test(this.RegisterObj.applicantPan))
      this.errPan="";
    else
      this.errPan="Please enter valid Pancard number";

  }

  applyForBankAccount() {
    this.validateData();
    this.MinMobile();
    this.MinAadhar();
    this.errMsgDt = "";
    if (this.errMsg1 == "" && this.errMsg2 == "" && this.errEmail == "" && this.errPan == "" && this.validMsg == "") {
      console.log('applyForBankAccount() invoking addApplicantService()..');
      this.RegisterObj.applicationStatus = "Applied";
      this.regServ.addApplicantService(this.RegisterObj).subscribe(
        (data: any) => {
          this.msg = data;
          console.log(this.msg);
          if(this.msg == "DOB Invalid"){
            this.errMsgDt = "Minimum age to apply for account is 18 years";
          }
          else if (this.msg == "Failed") {
            this.router.navigate(['/registration/unsuccess']);
          }
          else if (this.msg.match("Service")) {
            this.router.navigate(['/registration/success'], {state: {data: this.msg}});
          }
        },
        (err) => {
          console.log(err);
          this.router.navigate(['/registration/unsuccess']);
        }
      )
    }
  }

  validateData() {
    this.validMsg = "";
    this.RegisterObj.applicantName = this.RegisterObj.applicantName.trim();
    this.RegisterObj.applicantFatherName = this.RegisterObj.applicantFatherName.trim();
    this.RegisterObj.emailId = this.RegisterObj.emailId.trim();
    this.RegisterObj.applicantPan = this.RegisterObj.applicantPan.trim();
    this.RegisterObj.address = this.RegisterObj.address.trim();
    if (this.RegisterObj.salutation == "" || this.RegisterObj.applicantName.trim() == "" || this.RegisterObj.applicantFatherName.trim() == ""
      || this.RegisterObj.applicantGender == "" || this.RegisterObj.emailId.trim() == "" || this.RegisterObj.applicantPan.trim() == ""
      || this.RegisterObj.applicantOccupation == "" || this.RegisterObj.married == "" || this.RegisterObj.address.trim() == "") {
      this.validMsg = " Please enter all fields."
    }
    else
      this.validMsg = "";
  }
 
}
