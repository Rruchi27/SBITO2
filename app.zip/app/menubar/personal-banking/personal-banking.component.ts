import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-banking',
  templateUrl: './personal-banking.component.html',
  styleUrls: ['./personal-banking.component.css']
})
export class PersonalBankingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
