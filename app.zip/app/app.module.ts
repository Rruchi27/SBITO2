import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';

import { RegistrationComponent } from './registration/registration.component';

import {HttpClientModule} from '@angular/common/http';
import { ApplicantComponent } from './applicant/applicant.component';


import { RegisterComponent } from './register/register.component';

import { MenubarComponent } from './menubar/menubar.component';
import { HomeComponent } from './menubar/home/home.component';
import { PersonalBankingComponent } from './menubar/personal-banking/personal-banking.component';
import { OpenAccountComponent } from './menubar/open-account/open-account.component';
import { ContactUsComponent } from './menubar/contact-us/contact-us.component';
import { SuccessComponent } from './success/success.component';
import { UnsuccessComponent } from './unsuccess/unsuccess.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
   
    RegistrationComponent,
    
    ApplicantComponent,


    RegisterComponent,
 
    MenubarComponent,
    HomeComponent,
    PersonalBankingComponent,
    OpenAccountComponent,
    ContactUsComponent,
    SuccessComponent,
    UnsuccessComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
