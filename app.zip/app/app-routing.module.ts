import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AboutUsComponent } from './menubar/about-us/about-us.component';
import { ContactUsComponent } from './menubar/contact-us/contact-us.component';
import { HomeComponent } from './menubar/home/home.component';
import { MenubarComponent } from './menubar/menubar.component';
import { OpenAccountComponent } from './menubar/open-account/open-account.component';
import { PersonalBankingComponent } from './menubar/personal-banking/personal-banking.component';
import { RegisterComponent } from './register/register.component';
import { RegistrationComponent } from './registration/registration.component';
import { SuccessComponent } from './success/success.component';

const routes: Routes = [

 {path:'registration',
 children:[{path:'',component:RegistrationComponent},
 {path:'success',component:SuccessComponent}]},
 {path:'success',component:SuccessComponent},
 {path:'menubar',
 children:[{path:'',component:MenubarComponent},
 {path:'home',component:HomeComponent},
 {path:'personal-Banking',component:PersonalBankingComponent},
 {path:'open-account',component:OpenAccountComponent},
 {path:'about-us',component:AboutUsComponent},
 {path:'contact-us',component:ContactUsComponent}
]
}
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
