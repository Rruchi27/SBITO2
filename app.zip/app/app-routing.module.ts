import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AboutUsComponent } from './menubar/about-us/about-us.component';
import { ContactUsComponent } from './menubar/contact-us/contact-us.component';
import { HomeComponent } from './menubar/home/home.component';
import { MenubarComponent } from './menubar/menubar.component';
import { OpenAccountComponent } from './menubar/open-account/open-account.component';
import { PersonalBankingComponent } from './menubar/personal-banking/personal-banking.component';
import { RegisterComponent } from './register/register.component';
import { RegistrationComponent } from './registration/registration.component';
import { SuccessComponent } from './success/success.component';
import { UnsuccessComponent } from './unsuccess/unsuccess.component';

const routes: Routes = [
 {path:'',redirectTo:'/home',pathMatch:'full'},
 {path:'registration',
 children:[{path:'',component:RegistrationComponent},
 {path:'success',component:SuccessComponent},
 {path:'unsuccess',component:UnsuccessComponent}]},
 {path:'success',component:SuccessComponent},
 {path:'menubar',
 children:[{path:'',component:MenubarComponent},
 {path:'home',component:HomeComponent},
 {path:'personalbanking',component:PersonalBankingComponent},
 {path:'open-account',component:OpenAccountComponent},
 {path:'aboutus',component:AboutUsComponent},
 {path:'contactus',component:ContactUsComponent}
]
}
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
