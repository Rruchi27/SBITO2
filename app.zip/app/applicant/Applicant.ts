import { Address } from "./Address";

export class Applicant
{
  applicantid: number=0;
  accounttype: string="";
  applicantName: string="";	
  applicantFatherName: string="";	
  applicantBirthdate:Date=new Date();
  mobileNumber: string="";
  married: string="";
  addressList: Address[]= [];	
  aadharNumber: string="";
  panCard: string="";
  photo: string="";
  applicantAnnualIncome: number=0;
  occupation: string="";
  applicationStatus: string="";

}