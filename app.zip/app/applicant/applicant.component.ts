import { Component, OnInit } from '@angular/core';
import { ApplicantService } from '../applicant.service';
import { Applicant } from './Applicant';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {
 
  applicantArray: Applicant[] =[];
  fetchAllApplicantService: any;
  constructor(private apl: ApplicantService) { }

  ngOnInit(): void {
    this.fetchAllApllicants();
  }

  fetchAllApllicants()
  {
    this.apl.fetchAllApplicantService().subscribe(
      (data:Applicant[])=>
      {
        this.applicantArray = data;
        console.log(data);
      },
      (err: any) =>
      {
        console.log(err);
      }

    );
  }
 
  

}
