import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unsuccess',
  templateUrl: './unsuccess.component.html',
  styleUrls: ['./unsuccess.component.css']
})
export class UnsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
