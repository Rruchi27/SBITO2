package com.sbi.project.layer4;
import com.sbi.project.layer2.*;
import com.sbi.project.layer3.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.sbi.layer2.Applicant;
//import com.sbi.layer3.ApplicantRepository;
//import com.sbi.layer3.ApplicantRepositoyImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService 
{
	@Autowired
	ApplicantRepository appRepo;
	
	@Override
	public void createApplicationService(Applicant app) {
		
		appRepo.createApplicant(app);
		System.out.println("Applicant serviceImpl{} created ");
	}

	public List<Applicant> getAllApplicants() {
		return appRepo.findAllApplicants();
	}

	@Override
	public void removeApplicant(int applicantId) {
		// TODO Auto-generated method stub
		appRepo.removeApplicant(applicantId);
		System.out.println("Applicant serviceImpl{} removed");
	}

	@Override
	public void modifyApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		appRepo.modifyApplicant(applicant);
	}

	@Override
	public Applicant findApplicant(int applicantId) {
		// TODO Auto-generated method stub
		return appRepo.findApplication(applicantId);
	}
}
