package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@CrossOrigin //(origins = "*", value = "*")
@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	
	@Autowired
	ApplicantService appService;
	
	public ApplicantController() {
		System.out.println("ApplicantController() constructor...");
	}
	
	@RequestMapping("/getApplicants") 
	public List<Applicant> getAllApplicants()
	{
		System.out.println("/getApplicants");
		return appService.getAllApplicants();
	}
	
	@RequestMapping("/getApplicant/{applicantId}") 
	public Applicant getApplicant(@PathVariable("applicantId") int applicantId)
	{
		System.out.println("/getApplicant");
		return appService.findApplicant(applicantId);
	}
	
	@PostMapping("/addApplicants")
	public String addApplicant(@RequestBody Applicant newApplicant) {
		appService.createApplicationService(newApplicant);
		return "Applicant sucessfully created";
	}
	
	
	@RequestMapping("/deleteApplicants/{applicantId}") 
	public String deleteApplicant(@PathVariable("applicantId") int applicantIdToDelete)
	{
		Applicant applicant = appService.findApplicant(applicantIdToDelete);
//		List<Applicant> customer =appService.getAllApplicants();
//     System.out.println("/{applicantId}");
//     boolean applicantFound=false;
//     Applicant applicantObj =null;
//     for(int i=0;i<customer.size();i++)
//     {
//    	 applicantObj = customer.get(i);
//    	 if(applicantObj.getApplicantId() == applicantIdToDelete)
//    	 {
//    		 applicantFound = true;
//    		 appService.removeApplicant(applicantIdToDelete);
//				break;
//    	 }
//     }
//     
     if(applicant!=null) {
    	 appService.removeApplicant(applicantIdToDelete);
 		return "Customer Object deleted: " + applicantIdToDelete;
     }
 	else 
 		return "Customer Object not found: " + applicantIdToDelete;
      
 }

	@PutMapping("/updateApplicants") 
	public String updateApplicant(@RequestBody Applicant applicantObjectToModify)
	{
		Applicant applicant = appService.findApplicant(applicantObjectToModify.getApplicantId());
//		List<Applicant> customer =appService.getAllApplicants();
//     System.out.println("/updateapplicants");
//     boolean applicantFound=false;
//     Applicant applicantObj =null;
//     for(int i=0;i<customer.size();i++)
//     {
//    	 applicantObj = customer.get(i);
//    	 if(applicantObj.getApplicantId() == applicantObjectToModify.getApplicantId())
//    	 {
//    		 applicantFound = true;
//    		 customer.remove(i);
//    		 customer.add(applicantObjectToModify);
//				break;
//    	 }
//     }
//     
     if(applicant!=null) {
    	appService.modifyApplicant(applicantObjectToModify);
 		return "Customer  updated: " + applicantObjectToModify.getApplicantId();
     }
 	else 
 		return "Customer Object not found: " + applicantObjectToModify.getApplicantId();
      
 }

//	List<Employee> staff = new ArrayList<Employee>();
//	public ApplicantController()
//	{
//	
//	Employee emp =new Employee();
//	emp.setEmpId(101);
//	emp.setEmpName("Ruther");
//	emp.setEmpSalary(25000);
//	emp.setAge(32);
//	
//	Employee emp1 =new Employee();
//	emp1.setEmpId(102);
//	emp1.setEmpName("Rutherford");
//	emp1.setEmpSalary(28000);
//	emp1.setAge(34);
//	
//	Employee emp2 = new Employee(103, "Mark", 34000, 32);
//	Employee emp3 = new Employee(104, "Robert", 32000, 37);
//	staff.add(emp);
//	staff.add(emp1);
//	staff.add(emp2);
//	staff.add(emp3);
//	}
//	
//	@RequestMapping("/getEmps")     //localhost:8080/emps/getEmps
//	public List<Employee> empDetails()
//	{
////		Employee emp =new Employee(23,"Raj",25000);
////		System.out.println(emp);
////		return emp;
//		
//		System.out.println("/emps");
//		
//		return staff;
//				
//	}
//	
//	@RequestMapping("getEmp/{empId}")  //localhost:8080/emps/getemp/23
//	public Employee getEmployee(@PathVariable("empId") int empNumberTosearch)
//	{
//     System.out.println("/{empId}");
//     boolean employeeFound=false;
//     Employee employeeObj =null;
//     for(int i=0;i<staff.size();i++)
//     {
//    	 employeeObj = staff.get(i);
//    	 if(employeeObj.getEmpId() == empNumberTosearch)
//
//			{
//				employeeFound = true;
//				break;
//			}
//	}
//	if(employeeFound=true)
//		return employeeObj;
//	else 
//		return null;
//     
//}
//	
//	@RequestMapping("/deleteEmp/{empId}")  //localhost:8080/emps/deleteEmp/23
//	public String deleteEmployee(@PathVariable("empId") int empNumberToDelete)
//	{
//     System.out.println("/{empId}");
//     boolean employeeFound=false;
//     Employee employeeObj =null;
//     for(int i=0;i<staff.size();i++)
//     {
//    	 employeeObj = staff.get(i);
//    	 if(employeeObj.getEmpId() == empNumberToDelete)
//
//			{
//				employeeFound = true;
//				staff.remove(i);
//				break;
//			}
//	}
//	if(employeeFound==true)
//		return "Employee Object deleted: " + empNumberToDelete;
//	else 
//		return "Employee Object not found: " + empNumberToDelete;
//     
//}
//	
//	@RequestMapping("/updateEmp")  //localhost:8080/emps/updateEmp/23
//	public String updateEmployee(@RequestBody Employee employeeObjectToModify)
//	{
//     System.out.println("/updateEmp");
//     boolean employeeFound=false;
//     Employee employeeObj =null;
//     for(int i=0;i<staff.size();i++)
//     {
//    	 employeeObj = staff.get(i);
//    	 if(employeeObj.getEmpId() == employeeObjectToModify.getEmpId())
//
//			{
//				employeeFound = true;
//				staff.remove(i);
//				staff.add(employeeObjectToModify);
//				break;
//			}
//	}
//	if(employeeFound==true)
//		return "Employee updated ";
//	else 
//	{
//		staff.add(employeeObjectToModify);
//		return "Employee Object not found : "+ employeeObjectToModify.getEmpId();
//	}
//		
//	}
}


