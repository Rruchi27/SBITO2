package com.sbi.project;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;

@SpringBootTest
public class UserRegistrationRepoTest {

	@Autowired
	ApplicantRepository appRepo;
	
	@Test
	void addApplicantTest()
	{
		Applicant applicant = new Applicant();
		applicant.setSalutation("Er");
		applicant.setApplicantName("ramaswami");
		applicant.setApplicantFatherName("Lhinaswami");
		applicant.setApplicantBirthDate(LocalDate.of(2009, 5, 4));
		applicant.setApplicantGender("M");
		applicant.setEmailId("Duraiswami@gmail.com");
		applicant.setMobileNumber(8475456421l);
		applicant.setApplicantAadhar(426347741368l);
		applicant.setApplicantPan("TYRYD5579Y");
		applicant.setApplicantOccupation("Professional");
		applicant.setApplicantAnnualIncome(504000l);
		applicant.setApplicationStatus("Applied");
		applicant.setMarried("Single");
		applicant.setAddress("B-44, Sector-29,Belapur, Navi Mumbai");
		
		appRepo.createApplicant(applicant);
	}
	
	@Test
	void showApplicants()
	{
		List<Applicant> applicant = appRepo.findAllApplicants();
		for(Applicant appl : applicant) {
			System.out.println(appl);
		}
	}
	
	@Test
	void findApplicant()
	{
		Applicant applicant = appRepo.findApplication(13);
		
		Assertions.assertTrue(applicant!=null);
			System.out.println(applicant);
	}
	
	@Test
	void updateApplicant()
	{
		Applicant applicant = appRepo.findApplication(13);
		Assertions.assertTrue(applicant!=null);
		applicant.setApplicantFatherName("Lasitha");
		applicant.setApplicantAadhar(426347741369l);
		applicant.setApplicantPan("TYRYD5579Y");
		appRepo.modifyApplicant(applicant);
		
	}
	@Test
	void deleteApplicant()
	{
		Applicant applicant = appRepo.findApplication(13);
		
		Assertions.assertTrue(applicant!=null);
		appRepo.removeApplicant(applicant.getApplicantId());
	}
	
}
